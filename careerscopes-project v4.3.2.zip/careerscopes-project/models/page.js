// models/Page.js
const mongoose = require('mongoose');

const PageSchema = new mongoose.Schema({
  slug: { type: String, unique: true, required: true, index: true }, // e.g. "career_coaching"
  sections: { type: Map, of: String, default: {} }, // key -> HTML/string
  updatedAt: { type: Date, default: Date.now }
}, { minimize: false });

module.exports = mongoose.models.Page || mongoose.model('Page', PageSchema);
