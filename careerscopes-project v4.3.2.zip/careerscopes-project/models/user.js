// models/user.js
const mongoose = require('mongoose');
const bcrypt   = require('bcrypt');

// ---------- Subdocuments ----------
const DocumentSchema = new mongoose.Schema({
  originalname: String,
  filename:     String,
  mimetype:     String,
  size:         Number,
  url:          String,              // e.g. /uploads/:userId/:filename
  uploadedAt:   { type: Date, default: Date.now }
}, { _id: false });

const QuestionnaireSchema = new mongoose.Schema({
  // General profile / edu
  highestEducation:    String,
  interests:           [String],
  preferredIndustries: [String],
  skills:              [String],
  yearsExperience:     Number,

  // Psychometric Step 1 fields
  careerInterest:   String,
  skillsConfidence: String,
  workEnvironment:  String,
  desiredRoles:     [String],
  growthAreas:      [String],
  salaryRange:      String,
  availability:     String,
  additionalInfo:   String,
  links: {
    linkedin:  String,
    github:    String,
    portfolio: String
  },
  uploadNotes: String
}, { _id: false });


// ---------- Main User Schema ----------
const UserSchema = new mongoose.Schema({
  fullName: { type: String, required: true },                // matches your register form label
  email:    { type: String, required: true, unique: true, index: true },
  password: { type: String, required: true },                // hashed via pre('save')
  phone:    { type: String },
  state:    { type: String },

  // Step 3 services (array so multiple choices are supported)
  services: { type: [String], default: [] },

  // Step 1 / Step 2 data
  questionnaire: QuestionnaireSchema,
  documents:     [DocumentSchema]
}, { timestamps: true });

// ---------- Hooks & Methods ----------
// Hash password before save (only when modified)
UserSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// Compare plaintext password to hashed password
UserSchema.methods.comparePassword = function(candidate) {
  return bcrypt.compare(candidate, this.password);
};

// Avoid model overwrite on hot reload
module.exports = mongoose.models.User || mongoose.model('User', UserSchema);

